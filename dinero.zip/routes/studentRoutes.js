const express = require('express');
const router = express.Router();

const { pool } = require('../app'); 

router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query("SELECT * FROM tbl_student");
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', async (req, res) => {
    try {
        const [rows] = await pool.query("SELECT * FROM tbl_student WHERE id = ?", [req.params.id]);
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/', async (req, res) => {
    const { firstname, lastname, gender, age, course_id, department_id, status } = req.body;
    try {
        await pool.query("INSERT INTO tbl_student (firstname, lastname, gender, age, course_id, department_id, status) VALUES (?,?,?,?,?,?,?)", 
        [firstname, lastname, gender, age, course_id, department_id, status]);
        res.json({ message: "Student Added" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/:id', async (req, res) => {
    const { firstname, lastname, gender, age, course_id, department_id, status } = req.body;
    try {
        await pool.query("UPDATE tbl_student SET firstname=?, lastname=?, gender=?, age=?, course_id=?, department_id=?, status=? WHERE id=?", 
        [firstname, lastname, gender, age, course_id, department_id, status, req.params.id]);
        res.json({ message: "Student Updated" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.patch('/status/:id', async (req, res) => {
    try {
        await pool.query("UPDATE tbl_student SET status = ? WHERE id = ?", [req.body.status, req.params.id]);
        res.json({ message: "Status Updated" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', async (req, res) => {
    try {
        await pool.query("DELETE FROM tbl_student WHERE id = ?", [req.params.id]);
        res.json({ message: "Student Deleted" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;