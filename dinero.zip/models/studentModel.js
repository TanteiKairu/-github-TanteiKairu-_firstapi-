const db = require('../config/db');

const Student = {

    getAll: async () => {
        const [rows] = await db.query("SELECT * FROM tbl_student");
        return rows;
    },

    getById: async (id) => {
        const [rows] = await db.query("SELECT * FROM tbl_student WHERE id = ?", [id]);
        return rows[0];
    },

    create: async (data) => {
        const { firstname, lastname, gender, age, course_id, department_id, status } = data;
        const [result] = await db.query(
            "INSERT INTO tbl_student (firstname, lastname, gender, age, course_id, department_id, status) VALUES (?,?,?,?,?,?,?)",
            [firstname, lastname, gender, age, course_id, department_id, status]
        );
        return result;
    },
 
    update: async (id, data) => {
        const { firstname, lastname, gender, age, course_id, department_id, status } = data;
        return await db.query(
            "UPDATE tbl_student SET firstname=?, lastname=?, gender=?, age=?, course_id=?, department_id=?, status=? WHERE id=?",
            [firstname, lastname, gender, age, course_id, department_id, status, id]
        );
    },
  
    updateStatus: async (id, status) => {
        return await db.query("UPDATE tbl_student SET status = ? WHERE id = ?", [status, id]);
    },
 
    delete: async (id) => {
        return await db.query("DELETE FROM tbl_student WHERE id = ?", [id]);
    }
};

module.exports = Student;