const Student = require('../models/studentModel');

exports.getAllStudents = async (req, res) => {
    try {
        const students = await Student.getAll();
        res.status(200).json(students);
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.getStudentById = async (req, res) => {
    try {
        const student = await Student.getById(req.params.id);
        if (!student) return res.status(404).json({ message: "Student not found" });
        res.status(200).json(student);
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.addStudent = async (req, res) => {
    try {
        await Student.create(req.body);
        res.status(201).json({ message: "Student Added Successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.updateStudent = async (req, res) => {
    try {
        await Student.update(req.params.id, req.body);
        res.json({ message: "Student Updated Successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.updateStatus = async (req, res) => {
    try {
        await Student.updateStatus(req.params.id, req.body.status);
        res.json({ message: "Status Updated Successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.deleteStudent = async (req, res) => {
    try {
        await Student.delete(req.params.id);
        res.json({ message: "Student Deleted Successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
};